import { motion } from 'framer-motion';
import { useState } from 'react';
import { MessageCircle, Server, Link2, ChevronRight, MoreHorizontal, UserPlus } from 'lucide-react';

const tags = [
  { label: 'own', color: '#9ca3af' },
  { label: '88', color: '#9ca3af' },
  { label: 'pic', color: '#9ca3af' },
  { label: '/ageplayers', color: '#f472b6' },
];

export default function DiscordProfile() {
  const [hovered, setHovered] = useState<string | null>(null);
  const [messageFocused, setMessageFocused] = useState(false);

  return (
    <div className="profile-scene">
      {/* Ambient glow blobs */}
      <div className="blob blob-1" />
      <div className="blob blob-2" />

      <motion.div
        className="profile-card"
        initial={{ opacity: 0, y: 32, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      >
        {/* Header Banner */}
        <div className="banner">
          <div className="banner-inner" />
          <div className="banner-actions">
            <button className="icon-btn" title="Add friend">
              <UserPlus size={15} strokeWidth={2} />
            </button>
            <button className="icon-btn" title="More">
              <MoreHorizontal size={15} strokeWidth={2} />
            </button>
          </div>
        </div>

        {/* Avatar */}
        <div className="avatar-wrap">
          <motion.div
            className="avatar-ring"
            whileHover={{ scale: 1.04 }}
            transition={{ type: 'spring', stiffness: 400, damping: 20 }}
          >
            <img src="/uploads/upload_1.png" alt="avatar" className="avatar-img" />
          </motion.div>
          <span className="status-dot" />
        </div>

        {/* Body */}
        <div className="profile-body">
          {/* Name row */}
          <div className="name-row">
            <div>
              <h1 className="display-name">frail</h1>
              <div className="username-row">
                <span className="username">perv17</span>
                <span className="badge">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#6366f1" />
                    <path d="M8 12l3 3 5-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="divider" />

          {/* Mutual server */}
          <motion.div
            className="info-row"
            whileHover={{ x: 3 }}
            transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          >
            <div className="info-icon-wrap server-icon">
              <Server size={12} strokeWidth={2.5} />
            </div>
            <span className="info-label">1 Mutual Server</span>
            <ChevronRight size={13} className="info-chevron" />
          </motion.div>

          {/* Link */}
          <motion.a
            href="https://t.me/fwfrail"
            target="_blank"
            rel="noopener noreferrer"
            className="info-row link-row"
            whileHover={{ x: 3 }}
            transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          >
            <div className="info-icon-wrap link-icon">
              <Link2 size={12} strokeWidth={2.5} />
            </div>
            <span className="link-text">t.me/fwfrail</span>
          </motion.a>

          {/* Divider */}
          <div className="divider" />

          {/* Tags */}
          <div className="tags-section">
            <p className="tags-label">Member of</p>
            <div className="tags-wrap">
              {tags.map((tag) => (
                <motion.span
                  key={tag.label}
                  className="tag"
                  style={{ '--tag-dot': tag.color } as React.CSSProperties}
                  whileHover={{ scale: 1.06, y: -1 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                  onHoverStart={() => setHovered(tag.label)}
                  onHoverEnd={() => setHovered(null)}
                >
                  <span className="tag-dot" />
                  {tag.label}
                </motion.span>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="divider" />

          {/* Message box */}
          <motion.div
            className={`message-box ${messageFocused ? 'focused' : ''}`}
            whileHover={{ scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          >
            <input
              className="message-input"
              placeholder="Message @frail"
              onFocus={() => setMessageFocused(true)}
              onBlur={() => setMessageFocused(false)}
            />
            <button className="emoji-btn" title="Emoji">
              <span>😊</span>
            </button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

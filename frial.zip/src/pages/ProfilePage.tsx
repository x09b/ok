import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link2, Send } from 'lucide-react';

function DiscordIcon({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.033.054a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
    </svg>
  );
}

const LINKS = [
  { label: 'Telegram', href: 'https://t.me/fwfrail', Icon: Send, accent: false },
  { label: 'Discord', href: 'https://discord.gg/ageplayers', Icon: DiscordIcon, accent: true },
];

export default function ProfilePage() {
  const [entered, setEntered] = useState(false);

  return (
    <div className="root">
      {/* Background */}
      <div className="bg-layer">
        <img src="/bg.jpg" alt="" className="bg-img" />
        <div className="bg-overlay" />
        <div className="bg-vignette" />
      </div>

      {/* Grain texture */}
      <div className="grain" />

      {/* Click to enter gate */}
      <AnimatePresence>
        {!entered && (
          <motion.div
            className="gate"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            onClick={() => setEntered(true)}
          >
            <motion.div
              className="gate-inner"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <span className="gate-text">click to enter</span>
              <div className="gate-line" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <AnimatePresence>
        {entered && (
          <motion.main
            className="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            {/* Top bar */}
            <motion.div
              className="topbar"
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            >
              <span className="topbar-uid">UID 24,115</span>
            </motion.div>

            {/* Hero name block */}
            <div className="hero">
              <motion.h1
                className="hero-name"
                initial={{ opacity: 0, y: 28, filter: 'blur(8px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                transition={{ delay: 0.25, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              >
                frail
              </motion.h1>
              <motion.p
                className="hero-sub"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              >
                perv17
              </motion.p>
            </div>

            {/* Links */}
            <motion.div
              className="links-block"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.55, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            >
              <p className="section-label">links</p>
              {LINKS.map(({ label, href, Icon, accent }, i) => (
                <motion.a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`link-card${accent ? ' link-card-accent' : ''}`}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.62 + i * 0.1, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                  whileHover={{ x: 7, scale: 1.015 }}
                >
                  <div className={`link-icon-wrap${accent ? ' link-icon-accent' : ''}`}>
                    <Icon size={14} />
                  </div>
                  <span className="link-label">{label}</span>
                  <Link2 size={11} className="link-arrow" strokeWidth={2} />
                </motion.a>
              ))}
            </motion.div>

            {/* Footer */}
            <motion.footer
              className="footer"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9, duration: 0.5 }}
            >
              <span>discord profile</span>
              <span className="footer-dot">·</span>
              <span>frail</span>
            </motion.footer>
          </motion.main>
        )}
      </AnimatePresence>
    </div>
  );
}
